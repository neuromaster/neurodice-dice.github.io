<?php
namespace app\models;

class Commissions extends \lithium\data\Model {
}
?>