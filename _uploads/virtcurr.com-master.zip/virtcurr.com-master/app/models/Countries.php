<?php
namespace app\models;

class Countries extends \lithium\data\Model {
}
?>