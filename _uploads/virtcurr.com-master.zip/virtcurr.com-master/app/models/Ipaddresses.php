<?php
namespace app\models;

class Ipaddresses extends \lithium\data\Model {
}
?>