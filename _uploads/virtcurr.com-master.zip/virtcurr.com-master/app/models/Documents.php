<?php
namespace app\models;

class Documents extends \lithium\data\Model {
}
?>