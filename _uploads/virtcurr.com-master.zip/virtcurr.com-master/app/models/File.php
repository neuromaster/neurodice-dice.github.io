<?php
namespace app\models;

class File extends \lithium\data\Model {
	protected $_meta = array('source' => 'fs.files');
}
?>