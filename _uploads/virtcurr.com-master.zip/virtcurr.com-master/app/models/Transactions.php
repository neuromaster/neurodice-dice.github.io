<?php
namespace app\models;

class Transactions extends \lithium\data\Model {
}
?>