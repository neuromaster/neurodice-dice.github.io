<?php
namespace app\models;

class Limits extends \lithium\data\Model {
}
?>