<?php
namespace app\models;

class Denominations extends \lithium\data\Model {
}
?>