<?php
namespace app\models;

class Details extends \lithium\data\Model {
}
?>