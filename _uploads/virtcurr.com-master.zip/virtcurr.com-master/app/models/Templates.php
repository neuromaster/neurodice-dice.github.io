<?php
namespace app\models;

class Templates extends \lithium\data\Model {
}
?>