<br>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title"><?=strtoupper($pagename)?></h3>
	</div>
	<div class="panel-body">
		<div class="row">
			<div class="col-md-12">
				<?php
						print_r($settings[$pagename])	;
				?>
			</div>
		</div>
	</div>
</div>