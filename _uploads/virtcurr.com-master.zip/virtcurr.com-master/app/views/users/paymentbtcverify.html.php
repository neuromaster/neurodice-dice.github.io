<h4>Withdraw BTC</h4>
<p>We have sent an email to your registered email address for verifying your withdrawal of BTC. Please check your email, click on the link in the email to withdraw the BTC.</p>.

<a href="/users/funding_btc" class="btn btn-primary">Funding BTC</a>
<a href="/users/funding_ltc" class="btn btn-primary">Funding LTC</a>
<a href="/users/funding_fiat" class="btn btn-primary">Funding Fiat</a>
<a href="/users/transactions" class="btn btn-primary">Transactions</a>
