<?php ?>
<h4>Payment successfully sent!</h4>
<p><?php 
print_r($message);	
?></p>
<a href="/users/funding_ltc" class="btn btn-primary">Withdraw funds</a>
<a href="/users/transactions" class="btn btn-primary">Transactions</a>